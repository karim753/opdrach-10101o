<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['naam'])) {
    $naam = htmlspecialchars($_POST['naam']);
    echo "Goedemiddag, " . $naam;
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['naam'])) {
    $naam = htmlspecialchars($_GET['naam']);
    echo "Goedemiddag, " . $naam;
} else {
    echo "Geen naam ontvangen.";
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Naam Invoeren</title>
</head>
<body>
<h1>Vul uw naam in</h1>

<form action="verwerk.php" method="post">
    <label for="naam">Naam:</label>
    <input type="text" id="naam" name="naam" required>
    <button type="submit">Verstuur (POST)</button>
</form>

<hr>

<form action="verwerk.php" method="get">
    <label for="naam-get">Naam:</label>
    <input type="text" id="naam-get" name="naam" required>
    <button type="submit">Verstuur (GET)</button>
</form>
</body>
</html>
